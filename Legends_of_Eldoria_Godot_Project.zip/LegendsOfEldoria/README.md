# LEGENDS OF ELDORIA — projeto Godot editável

## Requisitos
- Godot Engine 4.3 ou superior (recomendado Godot 4.7.x).
- Renderer Compatibility / GL Compatibility.

## Como abrir
1. Extraia o ZIP.
2. Abra o Godot.
3. Clique em **Importar** e selecione `project.godot`.
4. Abra o projeto e pressione **F6/F5** para executar.

## Controles
- A / D ou setas: mover.
- Espaço ou seta para cima: pular.
- J ou clique esquerdo: atacar.
- No celular: botões de toque na tela.

## Sistemas incluídos
- Combate corpo a corpo.
- Inimigos que perseguem e atacam o herói.
- XP, níveis, ouro, ataque e defesa.
- Atributos aumentam ao subir de nível.
- Cenário 2D desenhado por código com camadas, névoa e partículas.
- HUD e controles touch básicos.
- Projeto organizado em cenas e scripts separados.

## Onde editar
- `scripts/player.gd`: movimentação, ataque e desenho do herói.
- `scripts/enemy.gd`: comportamento, vida e aparência dos inimigos.
- `scripts/main.gd`: cenário, plataformas e posição dos inimigos.
- `scripts/game_state.gd`: progressão, XP, níveis e atributos.
- `scripts/hud.gd`: interface e controles de toque.
- `scenes/`: cenas independentes do jogo.

## Próximas expansões recomendadas
Inventário real com slots, equipamentos com bônus, árvore de habilidades, salvamento, animações por spritesheet, chefes, mapas conectados, missões e áudio.

Observação: esta é uma primeira base jogável/editável (vertical slice), não um RPG comercial finalizado. Os personagens e cenários atuais são placeholders vetoriais desenhados por código para facilitar a substituição por arte HD própria.

## Gerar APK pelo celular usando GitHub Actions
1. Crie uma conta no GitHub (se ainda não tiver) e crie um repositório novo.
2. Envie todos os arquivos desta pasta para o repositório, mantendo a pasta `.github/workflows` e o arquivo `export_presets.cfg`.
3. Abra a aba **Actions** do repositório.
4. Se aparecer uma confirmação para habilitar workflows, confirme.
5. Execute **Build Android APK** em **Run workflow** (ou faça um commit na branch `main`/`master`, que inicia a compilação automaticamente).
6. Quando terminar com sucesso, abra a execução e baixe o artefato `Legends-of-Eldoria-Android-APK`.
7. Extraia o ZIP do artefato e instale o APK no Android. É uma build de teste assinada com uma chave temporária de debug.

A compilação depende de downloads e serviços externos do GitHub/Godot; se falhar, consulte o log da etapa vermelha para corrigir a configuração.
