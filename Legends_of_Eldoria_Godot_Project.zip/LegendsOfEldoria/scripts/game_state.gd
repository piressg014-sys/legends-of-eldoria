extends Node

signal stats_changed

var level: int = 1
var xp: int = 0
var xp_to_next: int = 50
var gold: int = 0
var max_health: int = 100
var attack_power: int = 18
var defense: int = 2

func add_xp(amount: int) -> void:
    xp += amount
    while xp >= xp_to_next:
        xp -= xp_to_next
        level += 1
        xp_to_next = int(xp_to_next * 1.35) + 15
        max_health += 12
        attack_power += 4
        defense += 1
    stats_changed.emit()

func add_gold(amount: int) -> void:
    gold += amount
    stats_changed.emit()

func reset_run() -> void:
    level = 1
    xp = 0
    xp_to_next = 50
    gold = 0
    max_health = 100
    attack_power = 18
    defense = 2
    stats_changed.emit()
