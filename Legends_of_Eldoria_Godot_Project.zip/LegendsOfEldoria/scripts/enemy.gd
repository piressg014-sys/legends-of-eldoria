extends CharacterBody2D

signal defeated

const GRAVITY := 1400.0
var health := 45
var speed := 95.0
var direction := -1
var attack_timer := 0.0
var hurt_flash := 0.0
var player: Node2D

func _ready() -> void:
    add_to_group("enemies")
    player = get_tree().get_first_node_in_group("player")

func _physics_process(delta: float) -> void:
    if hurt_flash > 0:
        hurt_flash -= delta
    if not is_instance_valid(player):
        player = get_tree().get_first_node_in_group("player")
    if is_instance_valid(player):
        var dx: float = player.global_position.x - global_position.x
        if abs(dx) < 360 and abs(dx) > 38:
            direction = int(sign(dx))
            velocity.x = direction * speed
        else:
            velocity.x = move_toward(velocity.x, 0, speed * delta * 3)
        if abs(dx) < 48 and abs(player.global_position.y - global_position.y) < 55:
            attack_timer -= delta
            if attack_timer <= 0:
                player.take_damage(12)
                attack_timer = 1.15
    if not is_on_floor():
        velocity.y += GRAVITY * delta
    move_and_slide()
    queue_redraw()

func take_damage(amount: int, knockback_direction: int) -> void:
    health -= amount
    hurt_flash = 0.16
    velocity.x = knockback_direction * 260
    velocity.y = -180
    if health <= 0:
        GameState.add_xp(25)
        GameState.add_gold(8)
        defeated.emit()
        queue_free()

func _draw() -> void:
    var body_color := Color("#ffb3a0") if hurt_flash > 0 else Color("#a94d65")
    draw_circle(Vector2(0, 12), 23, Color("#22243a"))
    draw_colored_polygon(PackedVector2Array([Vector2(-20,-20),Vector2(-14,-40),Vector2(0,-48),Vector2(15,-39),Vector2(21,-18),Vector2(15,22),Vector2(-16,22)]), body_color)
    draw_colored_polygon(PackedVector2Array([Vector2(-13,-38),Vector2(-24,-56),Vector2(-4,-48)]), Color("#e3b45b"))
    draw_colored_polygon(PackedVector2Array([Vector2(10,-40),Vector2(26,-55),Vector2(19,-30)]), Color("#e3b45b"))
    draw_circle(Vector2(-7,-19), 3, Color("#fff0c2"))
    draw_circle(Vector2(8,-19), 3, Color("#fff0c2"))
    draw_line(Vector2(-11, 25), Vector2(-17, 34), Color("#27263d"), 6)
    draw_line(Vector2(10, 25), Vector2(17, 34), Color("#27263d"), 6)
