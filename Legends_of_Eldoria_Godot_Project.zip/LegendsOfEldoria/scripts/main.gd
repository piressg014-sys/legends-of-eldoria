extends Node2D

const PLAYER_SCENE := preload("res://scenes/Player.tscn")
const ENEMY_SCENE := preload("res://scenes/Enemy.tscn")

var player: CharacterBody2D
var world_time := 0.0
var message_timer := 0.0
var message := "Explore a floresta e derrote criaturas para ganhar experiência!"

func _ready() -> void:
    GameState.reset_run()
    _create_platform(Vector2(640, 660), Vector2(1600, 120))
    _create_platform(Vector2(350, 520), Vector2(210, 24))
    _create_platform(Vector2(720, 430), Vector2(220, 24))
    _create_platform(Vector2(1060, 535), Vector2(250, 24))
    player = PLAYER_SCENE.instantiate()
    player.position = Vector2(170, 570)
    add_child(player)
    player.died.connect(_on_player_died)
    _spawn_enemy(Vector2(570, 575))
    _spawn_enemy(Vector2(930, 575))
    _spawn_enemy(Vector2(1120, 470))
    var hud := preload("res://scenes/HUD.tscn").instantiate()
    add_child(hud)
    hud.set_message(message)

func _process(delta: float) -> void:
    world_time += delta
    if message_timer > 0:
        message_timer -= delta
    queue_redraw()

func _create_platform(pos: Vector2, size: Vector2) -> void:
    var body := StaticBody2D.new()
    body.position = pos
    var shape := CollisionShape2D.new()
    var rect := RectangleShape2D.new()
    rect.size = size
    shape.shape = rect
    body.add_child(shape)
    add_child(body)

func _spawn_enemy(pos: Vector2) -> void:
    var enemy := ENEMY_SCENE.instantiate()
    enemy.position = pos
    add_child(enemy)

func _on_player_died() -> void:
    message = "Você foi derrotado! Toque em RECOMEÇAR para tentar novamente."
    message_timer = 999.0
    get_tree().call_group("hud", "show_game_over")

func restart_game() -> void:
    get_tree().reload_current_scene()

func _draw() -> void:
    # Céu em camadas
    draw_rect(Rect2(0,0,1280,720), Color("#10243b"))
    for i in range(8):
        var x := float(i) * 190.0 - 30.0
        draw_colored_polygon(PackedVector2Array([Vector2(x,0),Vector2(x+100,0),Vector2(x+240,660),Vector2(x-120,660)]), Color(0.12,0.35,0.43,0.16))
    # Lua e névoa
    draw_circle(Vector2(1030,125), 54, Color(0.55,0.88,0.92,0.12))
    draw_circle(Vector2(1030,125), 37, Color("#b5e5e4"))
    # Silhuetas de árvores distantes
    for i in range(12):
        var x := float(i) * 125.0 + 20
        draw_line(Vector2(x, 0), Vector2(x-25, 620), Color("#1b4551"), 12)
        draw_line(Vector2(x-25, 110), Vector2(x-90, 190), Color("#1b4551"), 8)
        draw_line(Vector2(x-20, 180), Vector2(x+50, 260), Color("#1b4551"), 7)
    # Plataforma principal
    draw_rect(Rect2(0,600,1280,120), Color("#26334a"))
    draw_rect(Rect2(0,600,1280,12), Color("#6e9b77"))
    for i in range(32):
        var x := i * 42
        draw_line(Vector2(x,610), Vector2(x-8,635), Color("#46634f"), 3)
    # Plataformas suspensas
    for r in [Rect2(245,508,210,14), Rect2(610,418,220,14), Rect2(935,523,250,14)]:
        draw_rect(r, Color("#55456a"))
        draw_rect(Rect2(r.position.x,r.position.y,r.size.x,5), Color("#8b9b78"))
    # Partículas mágicas
    for i in range(24):
        var px := fposmod(float(i)*73.0 + world_time*18.0, 1280.0)
        var py := 110.0 + fposmod(float(i)*47.0 + sin(world_time+i)*20.0, 430.0)
        draw_circle(Vector2(px,py), 2.0 + float(i%3), Color(0.56,0.94,0.92,0.45))

func _input(event: InputEvent) -> void:
    if event.is_action_pressed("ui_cancel"):
        get_tree().paused = not get_tree().paused
