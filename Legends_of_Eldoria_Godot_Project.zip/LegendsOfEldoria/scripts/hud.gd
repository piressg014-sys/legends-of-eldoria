extends CanvasLayer

var health_bar: ProgressBar
var xp_bar: ProgressBar
var level_label: Label
var gold_label: Label
var stats_label: Label
var message_label: Label
var game_over_panel: PanelContainer

func _ready() -> void:
    add_to_group("hud")
    _build_ui()
    var player := get_tree().get_first_node_in_group("player")
    if player:
        player.health_changed.connect(_on_health_changed)
    GameState.stats_changed.connect(_refresh_stats)
    _refresh_stats()

func _build_ui() -> void:
    var root := Control.new()
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(root)

    var top := PanelContainer.new()
    top.position = Vector2(22,18)
    top.custom_minimum_size = Vector2(360,112)
    root.add_child(top)
    var v := VBoxContainer.new()
    top.add_child(v)
    level_label = Label.new()
    level_label.add_theme_font_size_override("font_size", 22)
    v.add_child(level_label)
    health_bar = ProgressBar.new()
    health_bar.custom_minimum_size = Vector2(320,20)
    health_bar.show_percentage = false
    v.add_child(health_bar)
    xp_bar = ProgressBar.new()
    xp_bar.custom_minimum_size = Vector2(320,12)
    xp_bar.show_percentage = false
    v.add_child(xp_bar)
    stats_label = Label.new()
    v.add_child(stats_label)
    gold_label = Label.new()
    v.add_child(gold_label)

    message_label = Label.new()
    message_label.text = "WASD / setas: mover   •   Espaço: pular   •   J / clique: atacar"
    message_label.position = Vector2(350,22)
    message_label.add_theme_font_size_override("font_size", 18)
    root.add_child(message_label)

    # Controles touch para celular
    var left := _touch_button(root, "◀", Vector2(30,570), "move_left")
    var right := _touch_button(root, "▶", Vector2(112,570), "move_right")
    var jump_btn := _touch_button(root, "PULAR", Vector2(1020,570), "jump")
    var attack_btn := _touch_button(root, "ATACAR", Vector2(1130,570), "attack")
    left.custom_minimum_size = Vector2(72,72)
    right.custom_minimum_size = Vector2(72,72)
    jump_btn.custom_minimum_size = Vector2(100,72)
    attack_btn.custom_minimum_size = Vector2(110,72)

    game_over_panel = PanelContainer.new()
    game_over_panel.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
    game_over_panel.position = Vector2(-190,-90)
    game_over_panel.custom_minimum_size = Vector2(380,180)
    game_over_panel.visible = false
    root.add_child(game_over_panel)
    var over_box := VBoxContainer.new()
    game_over_panel.add_child(over_box)
    var over_label := Label.new()
    over_label.text = "FIM DE JOGO"
    over_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    over_label.add_theme_font_size_override("font_size", 28)
    over_box.add_child(over_label)
    var retry := Button.new()
    retry.text = "RECOMEÇAR"
    retry.pressed.connect(func(): get_tree().reload_current_scene())
    over_box.add_child(retry)

func _touch_button(parent: Control, caption: String, pos: Vector2, action: String) -> Button:
    var b := Button.new()
    b.text = caption
    b.position = pos
    b.custom_minimum_size = Vector2(72,72)
    b.modulate = Color(1,1,1,0.82)
    b.button_down.connect(func(): Input.action_press(action))
    b.button_up.connect(func(): Input.action_release(action))
    parent.add_child(b)
    return b

func _on_health_changed(current: int, maximum: int) -> void:
    health_bar.max_value = maximum
    health_bar.value = current

func _refresh_stats() -> void:
    if not is_instance_valid(level_label):
        return
    level_label.text = "HERÓI  •  NÍVEL %d" % GameState.level
    xp_bar.max_value = GameState.xp_to_next
    xp_bar.value = GameState.xp
    stats_label.text = "ATQ %d   DEF %d" % [GameState.attack_power, GameState.defense]
    gold_label.text = "✦  %d moedas" % GameState.gold

func set_message(value: String) -> void:
    if is_instance_valid(message_label):
        message_label.text = value

func show_game_over() -> void:
    game_over_panel.visible = true
