extends CharacterBody2D

signal health_changed(current: int, maximum: int)
signal died

const SPEED := 330.0
const JUMP_VELOCITY := -650.0
const GRAVITY := 1500.0

var health: int = 100
var facing: int = 1
var attacking := false
var attack_timer := 0.0
var invulnerable := 0.0
var attack_cooldown := 0.0
var hit_targets: Array[Node] = []

func _ready() -> void:
    add_to_group("player")
    health = GameState.max_health
    health_changed.emit(health, GameState.max_health)

func _physics_process(delta: float) -> void:
    if invulnerable > 0.0:
        invulnerable -= delta
    if attack_cooldown > 0.0:
        attack_cooldown -= delta
    if attacking:
        attack_timer -= delta
        if attack_timer <= 0.0:
            attacking = false
            hit_targets.clear()

    var direction := Input.get_axis("move_left", "move_right")
    if direction != 0:
        facing = int(sign(direction))
    velocity.x = direction * SPEED

    if not is_on_floor():
        velocity.y += GRAVITY * delta
    elif Input.is_action_just_pressed("jump"):
        velocity.y = JUMP_VELOCITY

    if Input.is_action_just_pressed("attack") and attack_cooldown <= 0.0:
        start_attack()

    move_and_slide()
    _check_attack_hits()
    queue_redraw()

func start_attack() -> void:
    attacking = true
    attack_timer = 0.24
    attack_cooldown = 0.38
    hit_targets.clear()

func _check_attack_hits() -> void:
    if not attacking:
        return
    var area := Rect2(Vector2(20 if facing > 0 else -100, -55), Vector2(95, 90))
    for enemy in get_tree().get_nodes_in_group("enemies"):
        if not is_instance_valid(enemy) or hit_targets.has(enemy):
            continue
        var local_enemy: Vector2 = to_local(enemy.global_position)
        if area.has_point(local_enemy):
            hit_targets.append(enemy)
            enemy.take_damage(GameState.attack_power, facing)

func take_damage(amount: int) -> void:
    if invulnerable > 0.0:
        return
    health = max(0, health - max(1, amount - GameState.defense))
    invulnerable = 0.75
    health_changed.emit(health, GameState.max_health)
    if health <= 0:
        died.emit()

func heal(amount: int) -> void:
    health = min(GameState.max_health, health + amount)
    health_changed.emit(health, GameState.max_health)

func _draw() -> void:
    var blink := invulnerable > 0.0 and int(Time.get_ticks_msec() / 80) % 2 == 0
    if blink:
        return
    # Capa
    draw_colored_polygon(PackedVector2Array([Vector2(-17,-23),Vector2(12,-22),Vector2(25,27),Vector2(-10,20)]), Color("#753caa"))
    # Pernas e botas
    draw_rect(Rect2(-12, 10, 10, 25), Color("#26334c"))
    draw_rect(Rect2(2, 10, 10, 25), Color("#26334c"))
    draw_rect(Rect2(-16, 31, 17, 7), Color("#171e30"))
    draw_rect(Rect2(0, 31, 17, 7), Color("#171e30"))
    # Corpo e armadura
    draw_colored_polygon(PackedVector2Array([Vector2(-15,-22),Vector2(14,-22),Vector2(17,12),Vector2(-16,12)]), Color("#287b91"))
    draw_line(Vector2(-12,-12), Vector2(12,4), Color("#f0c36b"), 4)
    # Cabeça e cabelo
    draw_circle(Vector2(0,-34), 14, Color("#e7b58c"))
    draw_colored_polygon(PackedVector2Array([Vector2(-14,-37),Vector2(-9,-51),Vector2(8,-50),Vector2(15,-39),Vector2(6,-43),Vector2(-3,-40)]), Color("#24233b"))
    draw_circle(Vector2(5,-34), 2, Color("#20243a"))
    # Braço
    draw_line(Vector2(10,-15), Vector2(22,-3), Color("#e7b58c"), 7)
    # Espada
    if attacking:
        var a := Vector2(23,-8)
        var b := Vector2(83,-65) * Vector2(facing, 1)
        draw_line(a, b, Color("#bcecff"), 8)
        draw_line(a, b, Color("#ffffff"), 3)
        draw_arc(Vector2(24,-8), 64, -1.25, 0.65, 24, Color("#7cecff"), 5)
    else:
        draw_line(Vector2(22,-3), Vector2(42, -29), Color("#d8e9f3"), 5)
        draw_line(Vector2(16,-7), Vector2(26,2), Color("#d3a34e"), 5)
